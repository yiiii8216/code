/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pokergame;

import java.net.URL;
import java.util.Random;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;

/**
 *
 * @author 98139
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Button start;
    @FXML
    private TextField suit;
    @FXML
    private TextField point;
    @FXML
    private TextArea display;
    @FXML
    private ImageView flower;
    @FXML
    private ImageView square;
    @FXML
    private ImageView heart;
    @FXML
    private ImageView peach;
    @FXML
    private ImageView win;
    @FXML
    private Button exit;
    @FXML
    private ImageView lose;
    @FXML
    private ImageView initial;
    @FXML
    private ImageView equlity;
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
   initial.opacityProperty().set(1);
 win.opacityProperty().set(0);             
 lose.opacityProperty().set(0);             
 equlity.opacityProperty().set(0);

    }    

    @FXML
    private void start(ActionEvent event) {
Random rnd=new Random(123);
     
int scores=0;
int  computerpoint=1+rnd.nextInt(12);
int computersuit=1+rnd.nextInt(4);
int userpoint=Integer.parseInt( point.getText() );
int  usersuit=Integer.parseInt( suit.getText() );
 String result;
 
 if(userpoint<4||usersuit<14){
      if(usersuit>computersuit){
            scores+=7;
             initial.opacityProperty().set(0);
             win.opacityProperty().set(1);
        }
       else if(usersuit<computersuit){
            scores-=2;    
            initial.opacityProperty().set(0);
             lose.opacityProperty().set(1);
        }
       else if(usersuit==computersuit){
            if(userpoint>computerpoint){
                scores+=3; 
            initial.opacityProperty().set(0); 
             win.opacityProperty().set(1);
            }
            else if(userpoint<computerpoint){
            scores-=2;
                initial.opacityProperty().set(0);
             lose.opacityProperty().set(1);
            }
            else if(userpoint==computerpoint){
           scores+=1;
             initial.opacityProperty().set(0);
             equlity.opacityProperty().set(1);
            }
        }
       
display.setText(String.format("得%d分", scores));
}else{
    display.appendText("輸入錯誤，請重新輸入\n");  
}
     }

    @FXML
    private void exit(ActionEvent event) {
        System.exit(0);
    }
    
    }
    
    

