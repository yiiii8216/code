#include <cstdlib>
#include <iostream>
#include <time.h>
#include "counting.hpp"
using namespace std;

COUNTING::COUNTING(){

}
int *counting(int i, int count, int c1, int c2, int c3)
{
    int p, num=i%13;
    switch (num)
    {
    case 2 ... 6:
        p =1;
        c1++;
        count++;
        break;
    case 7 ... 9:
        p= 0;
        c2++;
        break;
    case 0:
    case 1:
    case 10 ... 13:
        p =-1;
        c3++;
        count--;
        break;
    }
    int *counts = malloc(5 * sizeof(int));
    counts[0] = point;
    counts[1] = count;
    counts[2] = c1;
    counts[3] = c2;
    counts[4] = c3;
    return counts;
}
