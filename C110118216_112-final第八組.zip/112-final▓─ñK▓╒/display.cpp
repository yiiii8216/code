#include <cstdlib>
#include <iostream>
#include <time.h>
#include "display.hpp"
using namespace std;
DISPLAY::DISPLAY(){

}
void display()
{
    int *p_last; // �ŧi�@�ӫ��V���Ъ������ܼ�
    // �I�s card �禡���o�}�C
    int *pokers = cards(&p_last);
    int last_index = p_last - pokers;

    //---------------��l�]�w
    int  total=last_index+1, i;
    int *a, NoIn, point, count=0, T1=0, T2=0, T3=0, t ;
    char poker[total][2];

    printf( "Poker      Points     Counts     Category 1 Category 2 Category 3\n");
    for ( int i = 0; i < total; i++ )
    {
        // �P�_���  �ഫ(0/1/2/3)
        switch(((pokers[i]-1) / 13)%4)
        {
        case 0:
            poker[total][0] = 'S';
            printf("S");
            break;
        case 1:
            poker[total][0] = 'H';
            printf("H");
            break;
        case 2:
            poker[total][0] = 'D';
            printf("D");
            break;
        case 3:
            poker[total][0] = 'C';
            printf("C");
            break;
        }

        // ���J�P�Ʀr
        NoIn = pokers[i] % 13;
        switch(NoIn)
        {
        case 0:
            poker[total][1] = 'K';
            printf("K");
            break;
        case 1:
            poker[total][1] = 'A';
            printf("A");
            break;
        case 10:
            poker[total][1] = 'T';
            printf("T");
            break;
        case 11:
            poker[total][1] = 'J';
            printf("J");
            break;
        case 12:
            poker[total][1] = 'Q';
            printf("Q");
            break;
        default:
            poker[total][1] = NoIn;
            printf("%d", NoIn);
            break;
        }
        printf("         ");

        a=counting(*(pokers + i),count, T1, T2, T3);

        if(a[0]==1)
            printf("+%d         ",a[0]);
        else
            printf("%d         ",a[0]);

        if(a[1]>0)
            printf("+%d         ",a[1]);
        else
            printf("%d         ",a[1]);

        printf("%dcards     %dcards     %dcards     ",a[2],a[3],a[4]);

        count=a[1];
        c1=a[2];
        c2=a[3];
        c3=a[4];
        Sleep(1000);
        printf("\r");
    }
}
