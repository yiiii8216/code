#ifndef DISPLAY_HPP
#define DIAPALY_HPP
#include <cstdlib>
using namespace std;
class Display{
private:
 int mini, maxi, num;
 int* choose;
public:
 Display();
 int display();
};
#endif
