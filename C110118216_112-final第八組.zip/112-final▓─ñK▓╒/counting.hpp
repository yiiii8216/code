#ifndef COUNTING_HPP
#define COUNTING_HPP
#include <cstdlib>
using namespace std;
class COUNTING{
private:
 int mini, maxi, num;
 int* choose;
public:
 COUNTING();
 int Counting();
};
#endif

