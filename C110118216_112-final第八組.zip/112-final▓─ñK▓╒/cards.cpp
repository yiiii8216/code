#include <cstdlib>
#include <iostream>
#include <time.h>
#include "cards.hpp"
using namespace std;
CARDS::CARDS(int i, int count, int T1, int T2, int T3){

}
int * cards(int *p_last)
{
    srand((unsigned)time(NULL));
    int n = rand() % 6 + 1;
    int total = n * 52;
    int *pokers = malloc(total * sizeof(int));

    // ��l��
    for (int i = 0; i < total; i++)
        pokers[i] = i + 1;

    // �~�P
    for (int i = 0; i < total; i++)
    {
        int j = rand() % total;
        int tmp = pokers[i];
        pokers[i] = pokers[j];
        pokers[j] = tmp;
    }

    // �p��}�C�̫�@�Ӥ���������
    *p_last = &(pokers[total - 1]);
    return pokers;
}
