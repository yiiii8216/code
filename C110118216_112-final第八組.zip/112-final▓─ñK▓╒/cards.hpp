#ifndef CARDS_HPP
#define CARDS_HPP
#include <cstdlib>
using namespace std;
class Cards{
private:
 int mini, maxi, num;
 int* poker;
public:
 Cards(int min_num, int max_num, int number, int* ch);
 int cards();
};
#endif
